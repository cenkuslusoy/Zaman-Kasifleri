# Zaman Kaşifleri — Android MVP kaynak projesi

Güney, Aras ve Alp'in 4–6 yaş çocuklara yönelik, Türkçe yapay zekâ hikâye uygulaması.

## Bu pakette neler var?
- Android/Kotlin + Jetpack Compose uygulama iskeleti
- 10 macera dünyası ve görev seçimi
- Sunucu üzerinden hikâye üretimi için FastAPI endpoint'i
- Her hikâye sayfası için ayrı görsel üretimi (isteğe bağlı; maliyetlidir)
- Android'in yerleşik Türkçe Text-to-Speech motoruyla anlatıcı/karakter sesi ayrımı
- İlk ekip konsept görseli

## Önemli durum
Bu çalışma **ilk geliştirme kaynak paketi**dir; henüz imzalanmış/kurulabilir APK değildir. Bu çalışma ortamında Android SDK, Gradle ve Flutter kurulu olmadığından APK derlemesi yapılamadı. Ayrıca uygulamayı gerçek telefonda kullanmak için backend'in internete açık HTTPS adresine kurulması ve bu adresin Android yapılandırmasına yazılması gerekir.

## 1. Backend'i çalıştırma
Python 3.11+ gerekir.

```bash
cd backend
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
export OPENAI_API_KEY="YOUR_SERVER_SIDE_KEY"
export PUBLIC_BASE_URL="http://127.0.0.1:8000"
uvicorn main:app --host 0.0.0.0 --port 8000
```

`GET /health` sağlık kontrolü, `POST /story` hikâye üretim endpoint'idir.

Görsel üretimini geçici kapatmak için `GENERATE_IMAGES=0` kullanabilirsiniz. Görsel üretimi açıkken her sayfa için ayrı görsel üretilir ve API maliyeti oluşturur. API anahtarını asla Android uygulamasına eklemeyin.

## 2. Android sunucu adresini ayarlama
`app/build.gradle.kts` içindeki `API_BASE_URL` değerini backend'in HTTPS adresiyle değiştirin. Yerel Android emülatöründe `http://10.0.2.2:8000/` kullanılır. Fiziksel telefonda `10.0.2.2` çalışmaz; aynı ağdaki bilgisayarın IP'si veya internete açık HTTPS adresi gerekir. Üretimde HTTPS kullanın ve cleartext trafiğini kapatın.

## 3. APK derleme
Android Studio (JDK 17/21 uyumlu), Android SDK 35 ve Gradle 8.9+ kurulu bir makinede:

```bash
gradle wrapper --gradle-version 8.9
./gradlew assembleDebug
```

APK çıktısı: `app/build/outputs/apk/debug/app-debug.apk`

## Ürün kararları / sonraki işler
- Karakter yüz tutarlılığı için her karakterin ayrı, onaylanmış referans portresi ve görsel üretiminde referans-görsel destekli akış eklenmeli. Şu an backend prompt ile karakter tarifini tekrar ediyor; bu, tam yüz tutarlılığı garantisi değildir.
- Karakter diyalogları Android TTS'de farklı perde/hızla okunur; doğal ayrı sesler için sunucu TTS entegrasyonu sonraki aşamadır.
- Ebeveyn kapısı, süre sınırı, içerik raporlama, kayıtlı kitaplık, indirme/çevrimdışı okuma ve API maliyet sınırları tamamlanmalıdır.
- Çocuk uygulamasında hesap, kişisel veri ve serbest sohbet toplamaktan kaçının.
