import base64
import json
import os
import re
import uuid
from pathlib import Path
from typing import List, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from openai import OpenAI
from pydantic import BaseModel, Field

ROOT = Path(__file__).parent
IMAGE_DIR = ROOT / "generated"
IMAGE_DIR.mkdir(exist_ok=True)
client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
app = FastAPI(title="Zaman Kaşifleri API", version="0.1.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])
app.mount("/generated", StaticFiles(directory=str(IMAGE_DIR)), name="generated")

class StoryRequest(BaseModel):
    world: str = Field(min_length=2, max_length=60)
    mission: str = Field(min_length=2, max_length=400)
    minutes: int = Field(default=5, ge=3, le=10)
    age: int = Field(default=5, ge=4, le=6)

class Page(BaseModel):
    title: str
    narration: str
    dialogue: str = ""
    speaker: str = "Anlatıcı"
    image_prompt: str
    image_url: Optional[str] = None

class Story(BaseModel):
    title: str
    introduction: str
    pages: List[Page]

CHARACTER_BIBLE = (
    "Three recurring child adventurer cartoon characters, keep them visually consistent in every scene. "
    "Güney: boy on the left in the reference team artwork, short dark hair, blue hoodie, playful and energetic. "
    "Aras: boy in the middle, softly wavy light-brown hair, red neckerchief, clever and funny. "
    "Alp: boy on the right, short slightly tousled brown hair, hazel/green-brown eyes, denim-blue jacket, cheeky curious leader. "
    "They are close friends, age-appropriate child heroes. Adapt costumes to the selected era but preserve faces, hair, proportions and identities. "
    "High quality warm 3D animated family adventure film aesthetic, friendly expressions, colorful cinematic lighting."
)

@app.get("/health")
def health():
    return {"status": "ok", "service": "zaman-kasifleri"}

@app.post("/story")
def create_story(req: StoryRequest):
    if not os.environ.get("OPENAI_API_KEY"):
        raise HTTPException(503, "Server API key is not configured")
    prompt = f"""Write a Turkish illustrated adventure story for children aged {req.age}.
World/era: {req.world}. Mission: {req.mission}. Target spoken duration: {req.minutes} minutes.
Main trio: Güney, Aras and Alp, best friends. Keep these traits: Güney is energetic and playful; Aras is clever and funny; Alp is curious, cheeky and leads kindly.
Return ONLY valid JSON with keys title, introduction, pages. Make 6 pages. Each page has title, narration (2-3 short child-friendly sentences), dialogue (one short line), speaker (one of Güney, Aras, Alp), image_prompt (English visual prompt).
No frightening violence, weapons used to hurt people, death, gore, or perilous imitation instructions. Conflict is solved through teamwork, kindness and cleverness. For historical settings, distinguish fact from fantasy in a gentle way; do not present harmful colonial conquest as a heroic act. End warmly. Make every image prompt a distinct scene and include this character continuity description: {CHARACTER_BIBLE}"""
    try:
        completion = client.chat.completions.create(
            model=os.getenv("OPENAI_TEXT_MODEL", "gpt-4.1-mini"),
            response_format={"type": "json_object"},
            messages=[{"role": "system", "content": "You create safe, age-appropriate Turkish picture-book stories. Output valid JSON only."}, {"role": "user", "content": prompt}],
            temperature=0.8,
        )
        data = json.loads(completion.choices[0].message.content)
        story = Story.model_validate(data)
        # Generate a unique illustration for each page. Set GENERATE_IMAGES=0 to disable image generation during testing.
        if os.getenv("GENERATE_IMAGES", "1") == "1":
            for i, page in enumerate(story.pages):
                image_prompt = f"{CHARACTER_BIBLE} Scene: {page.image_prompt}. No text, no lettering, no watermark. Child-friendly storybook illustration."
                try:
                    image = client.images.generate(
                        model=os.getenv("OPENAI_IMAGE_MODEL", "gpt-image-1"),
                        prompt=image_prompt,
                        size="1024x1024",
                    )
                    raw = base64.b64decode(image.data[0].b64_json)
                    filename = f"{uuid.uuid4().hex}.png"
                    (IMAGE_DIR / filename).write_bytes(raw)
                    page.image_url = f"{os.getenv('PUBLIC_BASE_URL', 'http://10.0.2.2:8000')}/generated/{filename}"
                except Exception as image_error:
                    print(f"Image generation failed for page {i}: {image_error}")
        return {"title": story.title, "introduction": story.introduction, "pages": [p.model_dump() for p in story.pages]}
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(502, f"Story generation failed: {exc}")
